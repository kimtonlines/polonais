CREATE TRIGGER inbox_timestamp
  BEFORE INSERT
  ON inbox
  FOR EACH ROW
  BEGIN
    IF NEW.ReceivingDateTime = '0000-00-00 00:00:00' THEN
        SET NEW.ReceivingDateTime = CURRENT_TIMESTAMP();
    END IF;
END;

